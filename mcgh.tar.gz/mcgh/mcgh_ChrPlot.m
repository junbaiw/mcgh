function mcgh_ChrPlot(sorteddata,IA,IB,mean1,std1,final_name1,ch_final_ratio1,ch_final_std1,sorteddata3,colname3)
global numofrun chrom_rang xtick_labels xtick_locations iserrorBar ChrNo inter_value isAmpPlot ismcgh2
clf;

%added 2005 plot color labesl
if ~isempty (sorteddata3) & ~isempty(colname3)
   eval(['all_color_type=sorteddata3.',strvcat(colname3(2)),';']);
   color_type=unique(all_color_type);
   eval(['color_clone_name=sorteddata3.',strvcat(colname3(1)),';']);
   num_of_color_type=length(color_type) ; 
end    
%end added    


if isfield(sorteddata,'Chorsmor')
    Chor=(strvcat(sorteddata.Chorsmor(IA)));
else
    warndlg(['Chorsmor data not available!']);
    return;
end
if isfield(sorteddata,'position')
    if ChrNo<28
        Chor_position=str2num(strvcat(sorteddata.position(IA)));
    else
        Chor_position=str2num(strvcat(sorteddata.Order_Number(IA)));
    end
else
     warndlg(['Position data not available!']);
     return;
end

if isfield(sorteddata,'Order_Number')
    Genom_position=str2num(strvcat(sorteddata.Order_Number(IA)));
else
    warndlg(['Order number not available!']);
    return;
end


%Chor_position=str2num(strvcat(sorteddata.Order_Number(IA)));
%Genom_position=str2num(strvcat(sorteddata.position(IA)));


copynumber=ch_final_ratio1(IB);
copynumber_std=ch_final_std1(IB);

%add 12.17.2003
%idx_of_selected_Chor=find(Chor==ChrNo);
if ismcgh2==1
    if ChrNo<28
        idx_of_selected_Chor=find(str2num(Chor)==ChrNo); 
    else
        idx_of_selected_Chor=[];
        chr_idx=[];
        for i=1:24
            temp_idx=[];
            temp_idx=find(str2num(Chor)==i); 
            chr_idx=[chr_idx; max(max(Genom_position(temp_idx)))];
            idx_of_selected_Chor=[idx_of_selected_Chor ;temp_idx];
        end %end for
     end
else    
    if ChrNo<=22
        idx_of_selected_Chor=strmatch(num2str(ChrNo),Chor,'exact');
    elseif ChrNo==23
        idx_of_selected_Chor=strmatch('X',Chor,'exact');
    elseif ChrNo==24
        idx_of_selected_Chor=strmatch('Y',Chor,'exact');
    elseif ChrNo==25
        idx_of_selected_Chor=strmatch('OneQ',Chor,'exact');
    elseif ChrNo==26
        idx_of_selected_Chor=strmatch('OncoBAC',Chor,'exact');
    elseif ChrNo==27
        idx_of_selected_Chor=strmatch('Extra',Chor,'exact');
    elseif ChrNo==28
        idx_of_selected_Chor=[];
        chr_idx=[];
        for i=1:24
            temp_idx=[];
            if i<=22
                temp_idx=strmatch(num2str(i),Chor,'exact');
                chr_idx=[chr_idx; max(max(Genom_position(temp_idx)))];
            elseif i==23
                temp_idx=strmatch('X',Chor,'exact');
                chr_idx=[chr_idx; max(max(Genom_position(temp_idx)))];
            elseif i==24
                temp_idx=strmatch('Y',Chor,'exact');
                chr_idx=[chr_idx; max(max(Genom_position(temp_idx)))];
            end  
                idx_of_selected_Chor=[idx_of_selected_Chor ;temp_idx];
         end %end for        
    end %end if
end %end ismcgh2
%end added
    

if ~isempty(idx_of_selected_Chor)
    selected_Chor=Chor(idx_of_selected_Chor);
    %size(idx_of_selected_Chor)
    %size(Chor_position)
    %size(Genom_position)
    selected_Chor_position=Chor_position(idx_of_selected_Chor);
    selected_Genom_position=Genom_position(idx_of_selected_Chor);

    %selected_Chr_idx=Genom_position(chr_idx);
    selected_copynumber=copynumber(idx_of_selected_Chor);
    selected_copynumber_std=copynumber_std(idx_of_selected_Chor);

    if iserrorBar==1
        if ChrNo<28
            errorbar(selected_Chor_position,selected_copynumber,selected_copynumber_std,'.');
        else
            errorbar(selected_Genom_position,selected_copynumber,selected_copynumber_std,'.');
        end
    else
        if ChrNo<28
            plot(selected_Chor_position,selected_copynumber,'.');
	    if ~isempty(sorteddata3) & ~isempty(colname3)
        	copy_number_name=final_name1(IB);
        	uniq_copy_number_name=copy_number_name(idx_of_selected_Chor);
        	color_point=['r.';'g.';'y.';'c.';'k^'];
       	 	color_string={'red','green','yellow','cyan','black'};
        	for ci=1:num_of_color_type
            		label_idx=strmatch(color_type(ci),all_color_type,'row');
            		label_name=color_clone_name(label_idx);
            		[labels_name,label_uniq_idx1,label_uniq_idx2]=intersect(cellstr(lower(uniq_copy_number_name)),lower(label_name),'row');
            		label_x=selected_Chor_position(label_uniq_idx1,:);
            		label_y=selected_copynumber(label_uniq_idx1,:);
            		hold on;
            		plot(label_x,label_y,color_point(ci,:));  
            		marray_debuge([strvcat(color_type(ci)), ' is ', strvcat(color_string(ci)),' color!']);
        	end
 	        marray_debuge('\n');
    	  end
        else
            plot(selected_Genom_position,selected_copynumber,'.');
             if ~isempty(sorteddata3) & ~isempty(colname3)
                copy_number_name=final_name1(IB);
                uniq_copy_number_name=copy_number_name(idx_of_selected_Chor);
                color_point=['r.';'g.';'y.';'c.';'k^'];
                color_string={'red','green','yellow','cyan','black'};
                for ci=1:num_of_color_type
                        label_idx=strmatch(color_type(ci),all_color_type,'row');
                        label_name=color_clone_name(label_idx);
                        [labels_name,label_uniq_idx1,label_uniq_idx2]=intersect(cellstr(lower(uniq_copy_number_name)),lower(label_name),'row');
                        label_x=selected_Chor_position(label_uniq_idx1,:);
                        label_y=selected_copynumber(label_uniq_idx1,:);
                        hold on;
                        plot(label_x,label_y,color_point(ci,:));
                        marray_debuge([strvcat(color_type(ci)), ' is ', strvcat(color_string(ci)),' color!']);
                end %end for
		marray_debuge('\n');
              end %end if     
          end %end if
    end
    
    if ChrNo==28
        hold on
        plot(repmat(chr_idx,1,2)',repmat([ceil(min(selected_copynumber)-2) ceil(max(selected_copynumber))],24,1)','r-');
        %make xtick locations
        for idx=1:24
            if idx-1>0
            xtick_locations(idx)=(chr_idx(idx)-chr_idx(idx-1))/2+chr_idx(idx-1);
        else
            xtick_locations(idx)=chr_idx(idx)/2;   
        end
        end
        set(gca,'XTick',xtick_locations,'FontSize',6);
        set(gca,'XtickLabel',{'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','X','Y'});
    end
else
    warndlg(['Chromosome ', num2str(ChrNo), ' not available! Try again!']);
    return;
end

    
cl=selected_Chor;
hold on
%lnx=length(cl);
%added
if ChrNo<28
    lnx_b=min(min(selected_Chor_position));
    lnx_e=max(max(selected_Chor_position));
else
    lnx_b=min(min(selected_Genom_position));
    lnx_e=max(max(selected_Genom_position));
end

%pL1=plot(1:100:lnx,mean1,'-k','LineWidth',2);
pL1=line([lnx_b,lnx_e],[mean1, mean1]);

hold on
%pL2=plot(1:100:lnx,mean1+3*std1,'-k','LineWidth',2);
pL2=line([lnx_b,lnx_e],[mean1+3*std1,mean1+3*std1]);

hold on
%pL3=plot(1:100:lnx,mean1-3*std1,'-k','LineWidth',2);
pL3=line([lnx_b,lnx_e],[mean1-3*std1,mean1-3*std1]);

%plot ampl boundary
%plot(sorted_x,sorted_y,'m-','linewidth',1.5)
hold on
%[sorted_x ,sorted_y]=mcgh_fit_amplBoundary(final_ratio1,IA,IB);
if (inter_value ~=0 & isAmpPlot==1)
    %type 1
    %[sorted_x ,sorted_y]=mcgh_FitAmplBoundary(selected_copynumber,selected_Chor_position);
    
    %type 2
    %[sorted_x idx_x]=sort(selected_Chor_position);
    %sorted_y=selected_copynumber(idx_x);
    %yd=wden(sorted_y,'heursure','s','one',ceil(inter_value),'rbio1.1');
    
    %type 3
    [temp_selected_Chor_position, uniq_chor_idx]=unique(selected_Chor_position);
    temp_selected_copynumber=selected_copynumber(uniq_chor_idx);
    new_selected_chor_position=temp_selected_Chor_position;
    new_selected_copynumber=temp_selected_copynumber;
    
    [sorted_x idx_x]=sort(new_selected_chor_position);
    sorted_y=new_selected_copynumber(idx_x);
    
    N=length(sorted_y);
    max_D=ceil(log(N)/log(2));
    new_N=2^max_D;
    min_x=sorted_x(1);
    max_x=sorted_x(end);
    intervalue=(max_x-min_x)/(new_N-1);
    new_x=min_x:intervalue:max_x;
    new_y=interp1(sorted_x,sorted_y,new_x,'nearest');
    qmf8=MakeONFilter('Haar',8);
    D_level=ceil(inter_value);
    if D_level<=max_D
        [yd, wcoef]  = WaveShrink(new_y,'Visu',D_level,qmf8); 
        sorted_x=[];
        sorted_x=new_x;
    else
        %SURE
        %Visu
        [yd, wcoef]  = WaveShrink(new_y,'Visu',4,qmf8); 
        sorted_x=[];
        sorted_x=new_x;
        hd1=errordlg('Window size is too big please try again');
    end
 
    hold on;
    plot(sorted_x,yd,'m-','linewidth',1.5);
    %plot(sorted_x,sorted_y,'m-','linewidth',1.5)
elseif (inter_value ~=0 & isAmpPlot==2)
    %type 1
    [temp_selected_Chor_position, uniq_chor_idx]=unique(selected_Chor_position);
    temp_selected_copynumber=selected_copynumber(uniq_chor_idx);
    new_selected_chor_position=temp_selected_Chor_position;
    new_selected_copynumber=temp_selected_copynumber;
    [sorted_x ,sorted_y]=mcgh_FitAmplBoundary(new_selected_copynumber,new_selected_chor_position);
    hold on;
    plot(sorted_x,sorted_y,'m-','linewidth',1.5)
end



miny=min(selected_copynumber);
maxy=max(selected_copynumber);
%axis([0 lnx miny maxy]);
axis([lnx_b-1 lnx_e+1 miny-1 ceil(maxy)])

set(gca,'TickLength',[0,0]);
set(gca,'GridLineStyle','-');
%set(gca,'Xcolor',[0.7 0.7 0.8]);
%set(gca,'Ycolor',[1 0 1]);
set(gca,'Ycolor',[0 0 0]);
set(gca,'Color',[0.7 0.7 0.8]);
grid off
set(get(gca,'Children'),'ButtonDownFcn','mcgh_slctPoint_forChrPlot');
if ChrNo<23
    xl=xlabel(['Chromosome ',num2str(ChrNo),' (megabases from pter)']);
elseif ChrNo==23
    xl=xlabel(['Chromosome X (megabases from pter)']);
elseif ChrNo==24
    xl=xlabel(['Chromosome Y (megabases from pter)']);
elseif ChrNo==25
    xl=xlabel(['Chromosome OneQ (megabases from pter)']);
elseif ChrNo==26
    xl=xlabel(['Chromosome OncoBAC (megabases from pter)']);
elseif ChrNo==27
    xl=xlabel(['Chromosome Extra (megabases from pter)']);
elseif ChrNo==28
     xl=xlabel(['Chromosome 1 to Y (megabases from pter)']);
end

yl=ylabel('Relative copy number (log2)');
set(xl,'Color',[0 0 0],'FontSize',13);
set(yl,'Color',[0 0 0 ],'FontSize',13);
%xtick_locations
%set(gca,'XTick',xtick_locations,'FontSize',6);
%set(gca,'XtickLabel',xtick_labels);
yt=get(gca,'YTick');
xt=get(gca,'XTick');
set(gca,'FontSize',10);
int_xx=ceil(lnx_e/10);
for j=1:length(yt)
    xx=[0,lnx_e];
    yy=repmat(yt(j),1,length(xx));
    ln=line(xx,yy);
    %set(ln,'Color',[ 1 0 1]);
    set(ln,'Color',[0 0 0]);
end
%showone;
set(pL1,'Color',[0 1 0]);
set(pL1,'LineWidth',2);
set(pL2,'Color',[0 1 0]);
set(pL2,'LineWidth',2);
set(pL3,'Color',[0 1 0]);
set(pL3,'LineWidth',2);

