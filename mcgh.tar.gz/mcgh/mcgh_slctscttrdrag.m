global hrightaxes lS1 lP1 ycor ind1
currPt=get(hrightaxes,'CurrentPoint');
a = currPt(1,1);
b = currPt(1,2);

hold on
[ycor, ind1] = min((lS1-a).*(lS1-a)+(lP1-b).*(lP1-b));
loglog(lS1(~ind1),lP1(~ind1),'.')
showone;



