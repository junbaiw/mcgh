function mmcgh_multiExtract(sel_files,pathname,lnfile,v)
global fileform inter_value normtype clone_file_path
global stdBackIn maxStd_rep
global p_1 p1 p0 m1 m0 m_1 s_1 s1 s0
global str1 F1
global numofrun

%load data
waitn=6;
waiti=1;

if v==1 %selected files
    for ik=1:lnfile
        marray_debuge(['','\n']);
        marray_debuge(['','\n']);
        h = waitbar(1/waitn,'Please wait...');

        
        warning off;
        path1=pathname;
        file1=strvcat(sel_files(ik));
        if ~isempty(path1) & ~isempty(file1)
            filename1=[path1,file1];
            disp(['Load scanned file ',num2str(ik), ' :', filename1]);
        end
        if ~isempty(clone_file_path)
            filename=clone_file_path;
            disp(['Clone location file: ',filename]);
        end
    
        marray_debuge(['Loading : ',filename1]);
        data1=[];
        inputdata1=[];
        if fileform==1
            [data1,outputdata1,numofSpots1]=marray_testload_Quant(filename1);
            inputdata1=data1;
            marray_debuge('QuantArray output file');
        elseif fileform==2
            [data1,outdata,numofSpots,colnames]=marray_testload_GenPix(filename1);
            str_col=strvcat(colnames);
    
            inputdata1.X_Location=data1.X;
            inputdata1.Name=data1.Name;
            inputdata1.Y_Location=data1.Y;
        %
            idx_F6=strmatch('F6',strvcat(str_col));
            temp_names=str_col(idx_F6(1),:);
            ch1_wavelength=temp_names(2:4);
    
            idx_F5=strmatch('F5',strvcat(str_col));
            temp_names=str_col(idx_F5(1),:);
            ch2_wavelength=temp_names(2:4);
    
            eval(['inputdata1.ch1_Intensity=data1.F',ch1_wavelength,'_Mean;']);
            eval(['inputdata1.ch1_Background=data1.B',ch1_wavelength,'_Median;']);
            eval(['inputdata1.ch1_Background_Std_Dev=data1.B',ch1_wavelength,'_SD;']);
    
            eval(['inputdata1.ch2_Intensity=data1.F',ch2_wavelength,'_Mean;']);
            eval(['inputdata1.ch2_Background=data1.B',ch2_wavelength,'_Median;']);
            eval(['inputdata1.ch2_Background_Std_Dev=data1.B',ch2_wavelength,'_SD;']);
    
            inputdata1.Ignore_Filter=num2str(str2num(strvcat(data1.Flags))==0);
            inputdata1.Row=data1.Row;
            inputdata1.Column=data1.Column;
            inputdata1.Block=data1.Block;
            min_block=min(min(str2num(strvcat(data1.Block))));
            max_block=max(max(str2num(strvcat(data1.Block))));
            idx=1;
            for i=1:1
                for j=1:max_block
                    inputdata1.unique_print(idx,:)=[i,j];
                    idx=idx+1;
                end
            end
            marray_debuge('GenePiX output file');
        end

        waitbar(2/waitn,h);
        %%start to modify

        ref1or2=1;
        figno=11;
        alpha=1;
        ch1_int=1;
        ch2_int=1;
        ch1_intUser=0;
        ch2_intUser=0;
        [cond, newdata,newdata_intensity,q_com,q_com1,q_com2,idxq_com,rep_flag1,rep_flag2,minIntensity_ch1,minIntensity_ch2]...
            =mcgh_SfilterBad(inputdata1,ref1or2,normtype,figno,alpha,ch1_int,ch2_int,ch1_intUser,ch2_intUser);

        waitbar(3/waitn,h);

        filtered_ratio=newdata(:,2);
        idx_filtered=find(filtered_ratio~=0);
        norm_ratio1=filtered_ratio(idx_filtered);
        filtered_name1=inputdata1.Name(idx_filtered,:);
        %end modify

        len=length(norm_ratio1);
        f_name1=mcgh_BacName(len,filtered_name1);
        log2_norm1=log2(norm_ratio1);
        marray_debuge('Log2 transfer normalized ratio');
        [final_name1 , final_ratio1, final_std1,final_numofdup1]=mcgh_mean(f_name1,log2_norm1);
        
        waitbar(4/waitn,h);
        marray_debuge('Loading clone locations ..')
        [sorteddata,colname]=marray_testload_marray(filename);
        A=strrep(lower(deblank(sorteddata.BAC_PAC)),'_','');
        B=strrep(lower(deblank(final_name1)),'_','');
        [C IA IB]=intersect(A,B);
        %eval(str1);
        figure(40);
        mcgh_histfit(final_ratio1(IB),40,m1,s1,p1,m0,s0,p0,m_1,s_1,p_1);
        %marray_debuge(['The number of total clones is ',
        %num2str(length(IB))]);

        varnames=(A(IA));
        Chor=((sorteddata.Chorsmor(IA)));
        %Chor_position=str2num(strvcat(sorteddata.position(IA)));
        Genom_position=str2num(strvcat(sorteddata.Order_Number(IA)));

        lnIA=length((IA));
        IA=reshape(IA,lnIA,1);
        corrected_ratio=final_ratio1(IB)'-m0;
        %size(final_ratio1(IB)'),size(corrected_ratio),size(final_std1(IB)'),size(final_numofdup1(IB)'),size(Genom_position)

        outdata=[reshape(final_ratio1(IB),length(final_ratio1(IB)),1),...
            reshape(corrected_ratio,length(corrected_ratio),1),...
            reshape(final_std1(IB),length(final_std1(IB)),1),...
            reshape(final_numofdup1(IB),length(final_numofdup1(IB)),1),...
            reshape(Genom_position,length(Genom_position),1) ];


        %added jbw
        %original all names
        clear old_outdata old_corrected_ratio old_names

        len=size(inputdata1.Name,1);
        old_names=unique(mcgh_BacName(len,inputdata1.Name));
        [old_r old_c]=size(old_names);

        %old_outdata=[];old_corrected_ratio=[];old_names=[];
        old_r=max([old_r,old_c]);
        old_outdata=zeros(old_r,5); %GenPix data
        old_corrected_ratio=zeros(old_r,1);
        old_Chor=cellstr(repmat('NA',old_r,1));

        new_names=varnames; %clone location data
        [n_C,n_IA,n_IB]=intersect(strrep(lower(deblank(new_names)),'_',''),strrep(lower(deblank(old_names)),'_',''));
        old_outdata(n_IB,:)=outdata(n_IA,:);
        old_Chor(n_IB)=(Chor(n_IA));
        corrected_ratio=reshape(corrected_ratio,length(corrected_ratio),1);
        old_corrected_ratio(n_IB,:)=corrected_ratio(n_IA,:);
        old_names=(lower(deblank(old_names)));
        %end added

        casenames=strvcat({'Normalized ratio' , 'Mean center corrected Ratio','STD of ratio', 'Number of repeated spots','Chromosome','Genome position','All genome position'});
        
        waitbar(5/waitn,h);
        waitbar(6/waitn,h);
        close(h);
        %Export
        corrected_ratio=final_ratio1(IB)-m0;
        corrected_ratio=reshape(corrected_ratio,length(corrected_ratio),1);
        old_corrected_ratio=reshape(old_corrected_ratio,length(old_corrected_ratio),1);
        old_corrected_ratio(n_IB,:)=corrected_ratio(n_IA,:);
        mcgh_export(old_Chor,old_outdata,casenames,old_names,filename1,old_corrected_ratio,sorteddata);
       % marray_debuge(['Export file: ', filename1]);
       
    end %end for     
end %end if
