function [inputdata,outputdata,numofSpots,colnames]=marray_testload_GenPix(filename)
%deblank
% the input GenPix file should be tab deliments text file format
%otherwise this function will not work.
%Version 3.0
clear tempdata inputdata outputdata

t0=clock;
%filename
%filename='pax6_2_1_Dec19_colorswap_anal_nohead.txt'                                                                
%65_ps18_271101.gpr

%tempdata=[];
%inputdata=[];
%outputdata=[];
[fid,msg]=fopen(filename,'rt');
if fid<0
    error('Can not open file');
end
idx=1;
findInf=0;
while 1
    tline = fgets(fid);
    if ~ischar(tline)
        break,
    end
    if findInf==0
       %indeximage=strmatch('Block',tline);
       indeximage=findstr('Block',tline); %Added jbw 2006
       if isempty(indeximage)
          tempdata{idx}=tline;
       else
         if indeximage==1
           userInfo='Not available'; %read info
           findInf=1;
           dataidx=idx;
         else
          userInfo=strvcat(tempdata); %read info
          findInf=1;
          dataidx=idx; 
         end
          
          colname=marray_tabassign(tline,1);   %read column
          lncolname=length(colname);
          repidx=strmatch('Rgn_R',colname);
          for i=1:length(repidx)
              if strcmp(colname{repidx(i)},'Rgn_Ratio')~=1
              colname{repidx(i)}='Rgn_Ratio_squre';
              end
          end

          for i=1:lncolname
            tempname=strrep(deblank(colname{i}),'._','');
            tempname=strrep(tempname,' ','_');
            tempname=strrep(tempname,'.','');
            tempname=strrep(tempname,'%','Pr');
            tempname=strrep(tempname,'+','Plus');
            tempname=strrep(tempname,'-','Minus');
            tempname=strrep(tempname,'>','Gt');
            tempname=strrep(tempname,'(',''); %added May 06 2002
            tempname=strrep(tempname,')','');
            tempname=strrep(tempname,'/','v');
            tempname=strrep(tempname,'\','v');
            tempname=strrep(tempname,'?','');
	    tempname=strrep(tempname,'"','');	
            colname{i}=tempname;
         end
         tempdata2=cell(1,36000);
         tempdata2{1}=tline;
         temp=cell(16000,lncolname);
          %make input format %this is not so big imporvements
           %%str_inform=[ repmat('%s',[1 lncolname])];
           %%str_outform=cellstr([repmat('g',lncolname,1) strjust(num2str((1:lncolname)'),'left')  repmat(',',lncolname,1) ]);
           %%str_outform(lncolname)=strrep(str_outform(lncolname),',','');
           %%str_outform=strvcat(str_outform)';
           %%str11=['[' , reshape(str_outform,1,size(str_outform,1)*size(str_outform,2)) ']' ];
           %%str_load=[ str11 '=strread(tline,', '''', str_inform,'''',',','''delimiter''',',''\t\n'',','''whitespace''',',','''''' ');'];
      end
     end  %end if Block
     
     if findInf==1 & idx-dataidx>0
         %read data
          vardata=tline;
          tempdata2{idx-dataidx+1}=vardata;
          %eval(str_load);
          %eval(['varcol='str11 ';']);
          varcol=marray_tabassign2(vardata,lncolname);
          temp(idx-dataidx,:)=varcol(:);              
     end     
    idx=idx+1;
end
fclose(fid);

for j=1:lncolname
     tempname=strvcat(colname{j});
     eval(['inputdata.',tempname,'=temp(1:idx-dataidx-1,j);']);
end
outputdata=tempdata2(1,1:idx-dataidx);
numofSpots=length(inputdata.Block);
inputdata.userInfo=userInfo;
colnames=colname;
tt=etime(clock,t0); 
