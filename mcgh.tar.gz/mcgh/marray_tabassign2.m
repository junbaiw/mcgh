function colname=marray_tabassign_harbison(tempdata2,colnum)
%colnum=num of column
%tempdata2= line scane
clear colname tl;
%tempdata2=tline;
%colnum=20;

tl=strrep(deblank(tempdata2),' ','_');
lntemp=length(tl);
%colnum

%added 2006
%new_l=strrep(tl,char(9),';')
new_l=tl;
idx=findstr(char(9),strvcat(new_l));
ln_idx=length(idx);
colname=[];
if ~isempty(idx)
	for i=1:colnum
	      if ln_idx>1
		%more than two columns
   			if i<colnum 
				if i<=ln_idx	
					if i==1
						st=1;
					else
						st=idx(i-1)+1;
					end
					ed=idx(i)-1;
				else
					%missing last few columns
                                        st=-1;
                                        ed=-1;
				end
    			else
				if i<=ln_idx+1 
					st=idx(i-1)+1;
					ed=lntemp;
				else
					%missing last few columns
					st=-1;
					ed=-1;
				end
    			end
  		else
		%only two columns
     			if i==1
				st=1;
				ed=idx(i);
      			else
				st=idx(i-1)+1;
				ed=lntemp;
      			end
  		end
	       if st==-1& ed==-1
		       colname{i}='null'; %assign null for empty cell
	       else
    			colname{i}=new_l(st:ed);
	       end
	end
else 
    colname{1}='null'; %assign null for empty cell
end
%colname
%end added
%bug was fixed for missing values in the tab delimia files

%i=1;
%NEXTINDEX=0;
%[A,COUNT,ERRMSG,NEXTINDEX] =sscanf(tl(1:lntemp),str_format)
%while i<=colnum
%   % if i==1
%    %  [A,COUNT,ERRMSG,NEXTINDEX] =sscanf(tl(1:lntemp),'%s[^\t]')
%    %  totIDX=NEXTINDEX+1;
%    %else 
%    %  [A,COUNT,ERRMSG,NEXTINDEX] =sscanf(tl(totIDX:lntemp),'%s[^\t]')
%    %  totIDX=totIDX+NEXTINDEX   ; 
%  %end
%  [A,R]=strtok(tl,':')
%   tl=R;
%  disp('end')
%  pause
%colname{i}=A;
%i=i+1;
%end

%colnum=33;
%tempdata2=deblank(tempdata2);
%titlestring=tempdata2;
%tabIndx=marray_findtab(titlestring);
%lntab=length(tabIndx);
%lnstring=length(titlestring);

%colIndx=1:colnum-2;
%colIndx2=1:colnum-1;
%tb_bg(1)=1;
%tb_bg(2:length(colIndx)+1)=tabIndx(colIndx);
%tb_end=tabIndx(colIndx2);
%str_inform= ['''', repmat('%s',[1 colnum-1]) '%s','''']
%str_inform=[ repmat('%s',[1 colnum-1]) '%s']
%str_outform=cellstr([repmat('g',colnum,1) strjust(num2str((1:colnum)'),'left')  repmat(',',colnum,1) ])
%str_outform(colnum)=strrep(str_outform(colnum),',','');
%out_str=['[ ' str_outform ' ]'] 
%colname=[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,z1,z2,z3,z4,z5,z6,z7];
%[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,z1,z2,z3,z4,z5,z6,z7]= strread(li,str_inform,'delimiter','\t\n','whitespace','')
%colname=[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,z1,z2,z3,z4,z5,z6,z7];



