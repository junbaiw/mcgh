function [inputdata,outputdata,numofSpots,colnames]=marray_testload_GenPix_harbison(filename)
%deblank
% the input GenPix file should be tab deliments text file format
%otherwise this function will not work.
%Version 3.0
clear tempdata inputdata outputdata

t0=clock;
%filename
%filename='pax6_2_1_Dec19_colorswap_anal_nohead.txt'                                                                
%65_ps18_271101.gpr

%tempdata=[];
%inputdata=[];
%outputdata=[];
[fid,msg]=fopen(filename,'rt');
if fid<0
    error('Can not open file');
end
idx=1;
findInf=0;
tempdata=[];
while 1
    tline = fgets(fid);
    if ~ischar(tline)
        break,
    end
    if findInf==0
       %indeximage=strmatch('Block',tline);
       indeximage=findstr('Feature',tline); %Added jbw 2006
       if isempty(indeximage)
          tempdata{idx}=tline;
       else
         if indeximage==1
           userInfo='Not available'; %read info
           tempdata{idx}='Not available';
	   findInf=1;
           dataidx=idx;
         else
          userInfo=strvcat(tempdata); %read info
          findInf=1;
          dataidx=idx; 
         end
          
          colname=marray_tabassign(tline,1);   %read column
          lncolname=length(colname);
          repidx=strmatch('Rgn_R',colname);
          for i=1:length(repidx)
              if strcmp(colname{repidx(i)},'Rgn_Ratio')~=1
              colname{repidx(i)}='Rgn_Ratio_squre';
              end
          end

          for i=1:lncolname
            tempname=strrep(deblank(colname{i}),'._','');
            tempname=strrep(tempname,'R²','R2'); %added aug 2006
	    tempname=strrep(tempname,' ','_');
            tempname=strrep(tempname,'.','');
            tempname=strrep(tempname,'%','_');
            tempname=strrep(tempname,'+','_');
            tempname=strrep(tempname,'-','_');
            tempname=strrep(tempname,'>','Gt');
            tempname=strrep(tempname,'<','Ls'); %added aug 2006
	    tempname=strrep(tempname,'(',''); %added May 06 2002
            tempname=strrep(tempname,')','');
            tempname=strrep(tempname,'/','vsl');
            tempname=strrep(tempname,'\','vsr');
            tempname=strrep(tempname,'?','');
	    tempname=strrep(tempname,'"','');
	    tempname=strrep(tempname,':','_'); %added aug 2006
	    tempname=strrep(lower(tempname),lower('Background_substracted_density_in_Channel'),'BSDinCh');	
            tempname=strrep(lower(tempname),lower('Signal_Area_calculated_in_mm2_in_channel'),'SACinCh');
	    tempname=strrep(lower(tempname),lower('Signal_to_Noise_Ratio_in_Channel'),'StoNRinCh');
	    colname{i}=tempname;
         end
         tempdata2=cell(1,36000);
         tempdata2{1}=tline;
         temp=cell(16000,lncolname);
          %make input format %this is not so big imporvements
           %%str_inform=[ repmat('%s',[1 lncolname])];
           %%str_outform=cellstr([repmat('g',lncolname,1) strjust(num2str((1:lncolname)'),'left')  repmat(',',lncolname,1) ]);
           %%str_outform(lncolname)=strrep(str_outform(lncolname),',','');
           %%str_outform=strvcat(str_outform)';
           %%str11=['[' , reshape(str_outform,1,size(str_outform,1)*size(str_outform,2)) ']' ];
           %%str_load=[ str11 '=strread(tline,', '''', str_inform,'''',',','''delimiter''',',''\t\n'',','''whitespace''',',','''''' ');'];
      end
     end  %end if Block
     
     if findInf==1 & idx-dataidx>0
         %read data
          vardata=tline;
          tempdata2{idx-dataidx+1}=vardata;
          %eval(str_load);
          %eval(['varcol='str11 ';']);
          varcol=marray_tabassign_harbison(vardata,lncolname);
          temp(idx-dataidx,:)=varcol(:);              
     end     
    idx=idx+1;
end
fclose(fid);

for j=1:lncolname
     tempname=strvcat(colname{j});
     eval(['inputdata.',tempname,'=temp(1:idx-dataidx-1,j);']);
end
outputdata=tempdata2(1,1:idx-dataidx);
numofSpots=length(inputdata.column); %added aug 2006
inputdata.userInfo=userInfo;
colnames=colname;
tt=etime(clock,t0); 
