% MCGH Toolbox
% Version 1.0beta, August 15 2003
% 
% Copyright 2002-2003 by
% Junbai Wang
% Contributed files may contain copyrights of their own.
% Last modified in Feb. 2005
%
% MCGH Toolbox comes with ABSOLUTELY NO WARRANTY; for details
% see License.txt in the program package. This is free software,
% and you are welcome to redistribute it under certain conditions;
% see License.txt for details.
% 
% 
% mcgh
% 
%        mcghtoolbox   this file
%        License.txt   GNU General Public License 
%        Copyright.txt   Copyright notice
