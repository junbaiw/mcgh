function [sorted_x ,sorted_y]=mcgh_FitAmplBoundary(sel_final_ratio1,sel_IA)
global numofrun runcode numberofCenter inter_value m0 m1 m_1 s0 s1 s_1

xRaw=[];
yRaw=[];
sorted_xRaw=[];
sorted_yRaw=[];
xInt=[];
yInt=[];
x=[];
sorted_x=[];

%start fit ampl boundary
[xRaw,idx_xRaw]=unique(sel_IA); %clone location
t_yRaw=sel_final_ratio1'; %ratios
yRaw=t_yRaw(idx_xRaw);
norm_yRaw=yRaw; %som_normalize(yRaw,'var');
%mean(norm_yRaw)
%var(norm_yRaw)
[sorted_xRaw xRaw_idx]=sort(xRaw);
sorted_yRaw=norm_yRaw(xRaw_idx);
lenofX=length(xRaw);
%inter_value=3; %ceil(0.01*lenofX)
    xInt=sorted_xRaw(1):inter_value:sorted_xRaw(end);
   
yInt=interp1(sorted_xRaw,sorted_yRaw,xInt,'nearest');
yInt(find(isnan(yInt)==1))=0; %replace nan as zero


if numberofCenter==1
    c=2;
elseif numberofCenter==2
    c=3;
else
    error('Please choose right number of c-means centers');
end

x=yInt';
lenx=size(x,2);
y0=(rand(lenx,c)-0.5)*10e-5;
y0=y0';
epochs=100;
beta=1.3;
epc=0.00001;
N=10000;
isplot=0;
%first use fuzzy c-means/nGas find the center
%[fuzzy_center, fuzzy_member]=fuzzy_cmean(x,y0,c,epc,beta,N,isplot)
[fuzzy_center, fuzzy_member]=fuzzy_nGas(x,y0,c,beta,epochs);

[sorted_center sIdx]=sort(fuzzy_center);
sorted_x=[];
%sorted_center

%sorted_x=sort(norm_yRaw);
sorted_x=sort(yInt);
len_yint=length(yInt);
inter_value2=ceil(len_yint*0.05);
%sorted_x(1:inter_value2)
prototype=[];
temp_std=std(x);
temp_mean=mean(x);
if c==2
    %prototype=[m_1 m1];
    prototype=sorted_center';
    %prototype(1)=mean(mean(sorted_x(1:inter_value2)));
    %prototype(2)=mean(mean(sorted_x(end-inter_value2+1:end)));
elseif c==3
    
    %prototype=[(m_1-m0) m0-m0 (m1-m0)];
    %prototype=[temp_mean-3*temp_std m0-m0 temp_mean+3*temp_std]; 
    prototype(1)=mean(mean(sorted_x(1:inter_value2)));
    prototype(2)=sorted_center(2);
    prototype(3)=mean(mean(sorted_x(end-inter_value2+1:end)));
end

sorted_prototype=[];
sorted_prototype=sort(prototype);
Cp=[1:c]';
d=[];
d=sqrt(som_eucdist2(x,sorted_prototype'));
d(eye(size(d))==1)==NaN;
K=1;
beta=2;
[cc P]=fuzzy_knnnew(d,Cp,K,beta);
%find boundary value for each fuzzy center based on knn prototype -1, 0, 1
%ys=sum(P,2); %membership of all points
ys=nonzeros(P);
ampl_boundary=[];
for i=1:c
    [mem memIdx]=find(cc'==i);
    ampl_boundary(memIdx)=sorted_prototype(i)*ys(memIdx);
end
%%
xs=xInt;
[sorted_x sorted_xi]=sort(xs);
sorted_y=ampl_boundary(sorted_xi);

if runcode==1
 disp(['Estimated three centers: ', num2str(sorted_prototype)]);
end

%%%%%%end fit ampl boundary
