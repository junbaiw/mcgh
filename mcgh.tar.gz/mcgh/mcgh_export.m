function mcgh_export(Chor,outdata,casenames,varnames,filename1,corrected_ratio,sorteddata)
%test
%Chor=old_Chor;
%outdata=old_outdata;
%casenames=casenames;
%varnames=old_names;
%filename1=filename1;
%corrected_ratio=old_corrected_ratio;

outdata(:,2)=reshape(corrected_ratio,length(corrected_ratio),1);

%find genome location for all clones
%added Nov 200
A=strrep(strrep(lower(deblank(sorteddata.BAC_PAC)),'_',''),'"','');
B=strrep(strrep(lower(deblank(varnames)),'_',''),'"','');
[C IA IB]=intersect(A,B);
new_genom_position=zeros(max(size(B)),1);
new_genom_position=str2num(strvcat(sorteddata.Order_Number(IA)));
%new_varnames=cell(max(size(B)),1);
%new_varnames=B(IB,:);
%outdata=outdata(IB,:);
outdata(IB,end+1)=new_genom_position;
%end added Nov 2003

%added 12.17.2003
for i=1:length(varnames)
	if isempty(varnames{i})
		varnames{i}='empty';
	end
end

new_varnames=upper([strvcat(varnames),repmat(':',length(varnames),1),strvcat(Chor)]);
%end added

%added 3.2004
new_position=zeros(max(size(B)),1);
new_position=str2num(strvcat(sorteddata.position(IA)));
outdata(IB,end+1)=new_position;

new_chrom=zeros(max(size(B)),1);
temp_new_chrom=strrep(lower(sorteddata.Chorsmor),'extra','27');
temp_new_chrom=strrep(lower(temp_new_chrom),'y','24');
temp_new_chrom=strrep(lower(temp_new_chrom),'oneq','25');
temp_new_chrom=strrep(lower(temp_new_chrom),'oncobac','26');
temp_new_chrom=strrep(lower(temp_new_chrom),'x','23');
new_chrom=str2num(strvcat(temp_new_chrom(IA)));
outdata(IB,end-2)=new_chrom;
%end added 3.2004
if (exist('marray_testExportdata')~=0)
        marray_testExportdata(outdata,casenames,new_varnames,[filename1,'CLONERatio']);
        marray_debuge(['Export clone name with normalized ratios in [', filename1,'CLONERatio]']);
else
       disp('No export function !! I stop!');
end 
