function marray_SbefVaftnormPlot(red,green,red_normed,green_normed,ref1or2,figno)
warning off;
%remove flaged spots
idx1=find(red~=0&green~=0);
tmpred=red(idx1);
tmpgreen=green(idx1);
clear red green;
red=tmpred;
green=tmpgreen;

idx2=find(red_normed~=0 & green_normed~=0);
tmpred_normed=red_normed(idx2);
tmpgreen_normed=green_normed(idx2);
clear red_normed green_normed;
red_normed=tmpred_normed;
green_normed=tmpgreen_normed;

if ref1or2==2
    ystring=['M=log2(R/G)'];
    M=real(log2(red./green));
elseif ref1or2==1
    ystring=['M=log2(G/R)'];
     M=real(log2(green./red));
end
 

A=real(log2(sqrt(red.*green)));
[sortA , i]= sort(A);
sortM=M(i);

%Ms=lowess(sortA,sortM,0.5,2,6);
if ref1or2==2
    normM=real(log2(red_normed./green_normed));
elseif ref1or2==1
    normM=real(log2(green_normed./red_normed));
end
normA=real(log2(sqrt(red_normed.*green_normed)));

[sortnormA,i]=sort(normA);
sortnormM=normM(i);
%normMs=lowess(sortnormA,sortnormM,0.5,2,6);
xmin=min(sortA)-1;
xmax=max(sortA)+1;
xvect=xmin:xmax;
yvect=zeros(size(xvect));

figure(figno)
if figno==5
  set(figno,'position',[400 400 300 280])
elseif figno==6
  set(figno,'position',[700 400 300 280])
end;
%if figno==5
%  set(figno,'position',[600 64 340 600])
%elseif figno==6
%  set(figno,'position',[700 400 300 280])
%end;
  clf;
subplot(2,1,1)
plot(sortA,sortM,'.');
%hold on
%plot(sortA,Ms','r-');
hold on
plot(xvect,yvect,'g-');

%xlabel('A=log2(sqrt(R*G))');
ylabel(ystring);
if figno==5
  title('File1 Before Normalization');
elseif figno==6
  title('File2 Before Normalization');   
end

subplot(2,1,2)
plot(sortnormA,sortnormM,'.');
%hold on
%plot(sortnormA,normMs','r-');
hold on
plot(xvect,yvect,'g-');
title('After Simple Normalization');
xlabel('A=log2(sqrt(R*G))');
ylabel(ystring);