function [final_name , final_ratio, final_std, final_numofdup]=mcgh_mean(f_name1,log2_norm1,maxStd)
%Check repeated spots at input data and export the mean of repeated spots
%
global maxStd_rep

if nargin>2
    maxStd_rep=maxStd;
end
A=f_name1;
C=log2_norm1;
[B i j ]=unique(A);
idx=1;
id=1;
max_std=maxStd_rep/10;
for ri=1:length(i)
    temp_name=B{ri};
    idx_duplicated=find(j==ri);
    temp_ratio=C(idx_duplicated,:);
    temp_mean=mean(temp_ratio,1);
    temp_std=std(temp_ratio,0,1);
    lendup=length(idx_duplicated);
    if lendup>1 & temp_std<max_std
        final_name{idx}=temp_name;
        final_ratio(idx,:)=temp_mean;
        final_std(idx,:)=temp_std;
        final_numofdup(idx,:)=lendup;
        idx=idx+1;
    else
       
        %pause
        %temp_ratio
        %temp_std
        %disp('Select spot to delete :');
        delet_name{id}=temp_name;
        id=id+1;
    end
end
marray_debuge('Calculate the mean, standard deviation of repeated spots');
marray_debuge(['Delete ',num2str(id-1), ' clones with standard deviation > = ', num2str(max_std)]);   
