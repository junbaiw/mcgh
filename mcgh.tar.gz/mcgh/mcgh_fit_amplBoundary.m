function [sorted_x ,sorted_y]=mcgh_fit_amplBoundary(final_ratio1,IA,IB)
global numofrun runcode numberofCenter

%start fit ampl boundary
xRaw=IA; %clone location
yRaw=final_ratio1(IB)'; %ratios
%xInt=min(min(xRaw))1:max(max(xRaw));
%yInt=spline(xRaw,yRaw,xInt);
[sorted_xRaw xRaw_idx]=sort(xRaw);
sorted_yRaw=yRaw(xRaw_idx);
xInt=sorted_xRaw(1):5:sorted_xRaw(end);
yInt=spline(sorted_xRaw,sorted_yRaw,xInt);


x=yInt';
lenx=size(x,2);
sort_yInt=sort(yInt);
if numberofCenter==1
    c=2;
    y0(1)=mean(sort_yInt(1:5));
    y0(2)=mean(sort_yInt(end-4:end));

elseif numberofCenter==2
    c=3;
    y0(1)=mean(sort_yInt(1:5));
    y0(3)=mean(sort_yInt(end-4:end));
    y0(2)=0;
else
    error('Please choose right number of c-means centers');
end

%y0=(rand(lenx,c)-0.5)*10e-5;
%y0=y0'
y0=y0';
epochs=100;
beta=2;
epc=0.000001;
N=10000;
isplot=0;
%first use fuzzy c-means find the center
%[fuzzy_center, fuzzy_member]=fuzzy_cmean(x,y0,c,epc,beta,N,isplot);
[fuzzy_center, fuzzy_member]=fuzzy_nGas(x,y0,c,beta,epochs);
%compute the boundary for fuzzy_cmeans and fuzzy_nGas

if runcode==1
 disp(['Three centers estimated by Fuzzy-cmeans ', num2str(sort(fuzzy_center)')]);
end

xs=xInt;
[ys ysi]=max(fuzzy_member);
%find boundary value for each center -1, 0, 1
for i=1:c
    [mem memIdx]=find(ysi==i);
    ampl_boundary(memIdx)=fuzzy_center(i)*ys(memIdx);
end
%end for fuzzy_cmeans and fuzzy_nGas

%hold on;
[xx xxi]=sort(xs);
sorted_x=xx;
sorted_y=ampl_boundary(xxi);
%%%%%%end fit ampl boundary
