%MCGH: Matlab toolbox for analysising cDNA microarrray-based CGH experiemnts
%July. 2003. Tumor Biology Department, The norwegian radium hospital, 
%Author: junbai wang
%
global fileform inter_value normtype clone_file_path 
global stdBackIn maxStd_rep
global p_1 p1 p0 m1 m0 m_1 s_1 s1 s0
global str1 F1
global numofrun
warning off;
set(0,'ShowHiddenHandles','off')
if ( ~exist('GUIF1') ) 
    close all hidden;
    clear all;
    %close all hidden;
   GUIF1=0;
   find_cloneString='';
	%Default input values
   %Initial parameter
    m1=1.5;
    s1=0.2;
    p1=0.1;
    m0=0;
    s0=0.1;
    p0=0.8;
    m_1=-1.5;
    s_1=0.2;
    p_1=0.1;
    runcode=0;
    mcgh_plotter;
    F1=1;
    F2=2;
    isAmpPlot=3;
    numofrun=0;
    xtick_labels={};
    PlotMeanCenter=0;
    normtype=1;
    %isexport=1;
     waitn=6;
    numberofCenter=2;
    fileform=2;
    inter_value=3;
    iserrorBar=2;
    isloaded=1;
    maxStd_rep=2;
    stdBackIn=3;
    %define menue
     % h =0;
end;

if GUIF1==0
figure(F2); %   control window
set(F2,'Color',[0.8 1 1], ...
    'units','normalized', ... 
    'Position',[0.1 0.07 0.45 0.50], ...
   	'Tag','F2',...
    'NumberTitle','off',...
    'Name','MM-CGH');
	%'DoubleBuffer','on',...
    
frmPos=[1 50 520 310];
vvv=uicontrol(...
   'Style','frame', ...
   'Units','pixels', ...
   'Position',frmPos, ...
   'BackgroundColor',[0.5 0.5 0.5]);

%define menu
if ~exist('pmenu')
    pmenu=uimenu('Parent',F2,'Label','MM-CGH property'); 
    uimenu(pmenu,'Label','MCGH property','Callback','mmcgh_properties'); 
end

    
%open file1
openBut1=uicontrol('style','push','string','Open scaned File',...
	'position',[3 470 120 20], ...
	'callback', [' mmcgh_multiselect;numofrun=0;p1=0.1;p_1=0.1;p0=0.8;m1=1;m0=0;m_1=-1;s1=0.2;s_1=0.2;s0=0.1;mmcgh;'],...
	'Interruptible','on');
	if exist('file1')
 	file_name1=uicontrol('Style','text','HorizontalAlignment','left',...
 	'Position',[150 470 180 20],...
 	'String', file1); 
	end

%Open Input file2
	openBut2=uicontrol('style','push','string','Open Clone location File ',...
	'position',[3 440 120 20], ...
	'callback', [' [file2, path2]=uigetfile({''*.*'', ''All Files (*.*)''});numofrun=0;p1=0.1;p_1=0.1;p0=0.8;m1=1;m0=0;m_1=-1;s1=0.2;s_1=0.2;s0=0.1;mmcgh;clone_file_path=[path2,file2];'],...
	'Interruptible','on');
	if exist('file2')
  	file_name2=uicontrol('Style','text','HorizontalAlignment','left',...
 	'Position',[150 440 180 20],...
 	'String',file2); 
    end



%%normalization choice
ntype=uicontrol('Style','popupmenu',...
        'Position',[ 3 400 180 20],...   
        'String', 'Simple normalization|Intensity dependent normalization|Sub-array position normalization', ... %type1=1, type2=2
        'Callback',['numofrun=0;normtype=get(ntype,''Value'');p1=0.1;p_1=0.1;p0=0.8;m1=1;m0=0;m_1=-1;s1=0.2;s_1=0.2;s0=0.1;']);
%file type choice
ftype=uicontrol('Style','popupmenu',...
        'Position',[ 350 470 120 20],...   
        'String', 'QuantArray format|GenePix format', ... %type1=1, type2=2
        'Callback',['fileform=get(ftype,''Value'');numofrun=0;p1=0.1;p_1=0.1;p0=0.8;m1=1;m0=0;m_1=-1;s1=0.2;s_1=0.2;s0=0.1;']);
    
%
%  Exit Button ; exit the program
%
ExitBut=uicontrol('style','pushbutton',...
                 'string','EXIT','position', [3 5 50 20],...
                 'callback','close all hidden;clear all;');


             

%'Units','normalized'
%[.65 .85  .4 0.05]
%    'FontUnits', 'Normalized',...
%define intervalue for the window size
htxt_window_size=uicontrol('Parent',F2,...
		    'Style', 'text', ...
		    'Position',[350 440 120 20] ,...
		    'Backg', [1 1 1], ...
		    'Foreg', [0 0 0], ...
		    'String','Average window size', ...
		    'FontSize',1, ...
		    'FontWeight',  'normal', ...
		    'HorizontalAlignment', 'left', ...
		    'Tag', 'average_widdow_size');

window_size_field=uicontrol('Style','edit','Position', [460 440 50 20],...
         'BackgroundColor','white',...
         'CallBack',['inter_value=str2num(get(window_size_field,''String''));']);
   %[.91 .85  .08 0.05],...             
   % 'Units', 'normalized', ...
    
set(ntype,'Value',normtype);
set(ftype,'Value',fileform);
set(window_size_field,'String',num2str(inter_value));

all_parameters=[m1 s1 p1 m0 s0 p0 m_1 s_1 p_1];

end %end all

