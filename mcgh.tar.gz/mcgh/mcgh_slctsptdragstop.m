 global hleftaxes M1 ycor ind1
currPt=get(hleftaxes,'CurrentPoint');
a = currPt(1,1);
b = currPt(1,2);
	hold on
     pkr = M1(:,5);
     pkc = M1(:,6);
     [ycor, ind1] = min((( pkc-a).*(pkc-a) +(pkr-b).*(pkr-b))) ;
     showone;

