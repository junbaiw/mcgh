function [rat_normed,int_normed]=marray_Snorm_type1(ch2_redsub,ch2_greensub,sumch2_redsub,...
    sumch2_greensub,ref1or2,figno,idxq_com)
%Simple normalization of ratios 
%Input:
%ch2_redsub is channel 1 intensity after substracted background
%ch2_greensub is channel 2 intensity after substracted background
%sumch2_redsub is the sum of background substracted channel 1 intensity
%sumch2_greensub is the sum of background substracted channel 2 intensity
%ref1or2=1 compute ratio=ch2_greensub/ch2_redsub
%ref1or2=2 compute reatio=ch2_redsub/ch2_greensub
%figno is the figure number
%idxq_com is the ignore flag of input ch2_redsub and ch2_greensub
%Output:
%rat_normed is normalized ratio
%int_normed is normalized intensity
%The green line is the center of the data
%
%Notes:
%normalization type 1, assume both channel have
%equal intensity
warning off;
if ref1or2==1
	red_norm=sumch2_redsub./sumch2_redsub;
	green_norm=sumch2_greensub./sumch2_redsub; %Ch2/ch1 normalization factor=Green/red, ch1 as reference channel
   
	ch2_redInt_normed=ch2_redsub./red_norm;
	ch2_greenInt_normed=ch2_greensub./green_norm;
   
    red_ratio_normed=ch2_redInt_normed./ch2_redInt_normed;
	green_ratio_normed=ch2_greenInt_normed./ch2_redInt_normed;	
	% marray_debuge('Ratio=532/635');
elseif ref1or2==2
   red_norm=sumch2_redsub./sumch2_greensub;
   green_norm=sumch2_greensub./sumch2_greensub; %Ch1/ch2 normalization factor=Red/Green, ch2 as reference channel
   
   ch2_redInt_normed=ch2_redsub./red_norm;
   ch2_greenInt_normed=ch2_greensub./green_norm;
   red_ratio_normed=ch2_redInt_normed./ch2_greenInt_normed;
   green_ratio_normed=ch2_greenInt_normed./ch2_greenInt_normed;
   % marray_debuge('Ratio=635/532');
else
   disp('Please choose right channel to normalize');
   stop ;   
end

%replace inf, nan to zero
infidx=find(isinf(red_ratio_normed)==1); red_ratio_normed(infidx)=0;
nanidx=find(isnan(red_ratio_normed)==1); red_ratio_normed(nanidx)=0;
infidx=find(isinf(green_ratio_normed)==1); green_ratio_normed(infidx)=0;
nanidx=find(isnan(green_ratio_normed)==1); green_ratio_normed(nanidx)=0;

infidx=find(isinf(ch2_redInt_normed)==1); ch2_redInt_normed(infidx)=0;
nanidx=find(isnan(ch2_redInt_normed)==1); ch2_redInt_normed(nanidx)=0;
infidx=find(isinf(ch2_greenInt_normed)==1); ch2_greenInt_normed(infidx)=0;
nanidx=find(isnan(ch2_greenInt_normed)==1); ch2_greenInt_normed(nanidx)=0;

rat_normed=[red_ratio_normed, green_ratio_normed];
int_normed=[ch2_redInt_normed, ch2_greenInt_normed];  

idxgood=find(idxq_com==1);
marray_SbefVaftnormPlot(ch2_redsub(idxgood),ch2_greensub(idxgood),ch2_redInt_normed(idxgood),...
    ch2_greenInt_normed(idxgood),ref1or2,figno);

