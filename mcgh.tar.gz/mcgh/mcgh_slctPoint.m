global cloneName
figName=get(gcf,'Name');
if ~isempty(strmatch(figName,'Raw ratio plot','exact'))
    PlotMeanCenter=0;
else
    PlotMeanCenter=1;
end
currPt=get(gca,'CurrentPoint');
a = currPt(1,1);
b = currPt(1,2);
hold on
%if exist('p1') 
%    clf p1;
%end
plot(a,b,'ro');
%if ChrNo<28
%    M1=str2num(strvcat(sorteddata.position(IA))); 
%else
%    M1=str2num(strvcat(sorteddata.Order_Number(IA)));%IA;
%end
M1=str2num(strvcat(sorteddata.Order_Number(IA)));%IA;
if PlotMeanCenter~=1
    M2= final_ratio1(IB);
else
    M2=final_ratio1(IB)-m0;
end
M3=final_name1(IB);
pkc = M1;
pkr = M2;
%
%[ycor, ind1] = min((( pkc-a).*(pkc-a) +(pkr-b).*(pkr-b))) ;
%new condition added 11.2002
xlimit=abs(pkc-a*ones(size(pkc)))./abs(pkc);
lnX=length((xlimit));
xlimit=reshape(xlimit,lnX,1);
ylimit=abs(pkr-b*ones(size(pkr)))./abs(pkr);
lnY=length((ylimit));
ylimit=reshape(ylimit,lnY,1);
[minvalue ind1] =min((xlimit+ylimit)/2);
limit=0.005; %setup minmu 
if minvalue<=limit
   cloneName=M3(ind1);
   cloneRatio=M2(ind1);
   cloneLocation=M1(ind1);
else
    cloneName='not found';
    cloneRatio=0;
    cloneLocation=0;
end
%end add
%cloneName=M3(ind1);
figure(F2);
uicontrol('style','text','string',...
    cellstr(['Name: ',strvcat(cloneName),', Ratio: ',num2str(cloneRatio), ', Location: ', num2str(cloneLocation) ]), 'position',[sleng+30 5  280 40],...
    'Backg', [1 1 1],...
    'Foreg', [0 0 0],'FontWeight','bold');
