1. MCGH for analysis raw gpr or quantArray data
2. MMCGH for batch loading raw gpr or quantArray data and export all normalized ratios and clone locations.
3. MCGH2 for analysising the export data of MMCGH which runs faster than MCGH
4. If the interactive plot do not find right gene name for the data point please zoom in the figure by 
clicking the button of matlab figure zoom in then try to locate the spot again.
