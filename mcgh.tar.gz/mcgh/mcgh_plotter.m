%mr1=1;
%sr1=0.45;
%p1=0.1
%mr0=-0.1;
%sr0=0.2;
%p0=0.88
%mr_1=-1.2;
%sr_1=0.1;
%p_1=0.02
str1=['figure(F1);hold off;set(F1,''Name'',''Raw ratio plot''); PlotMeanCenter=0; subplot(2,1,1);'];
str1=[str1,'mcgh_histfit(final_ratio1(IB),40,m1,s1,p1,m0,s0,p0,m_1,s_1,p_1);'];
str1=[str1,'subplot(2,1,2);mcgh_plotClones(sorteddata,IA,IB,m0,s0,final_name1,final_ratio1,final_std1,sorteddata3,colname3);'];
%str1=[str1,prstr2,printfm];
printvalue=['figure(F2);for ksl=1:9;ns=char(nstring{ksl});ng(ksl)=uicontrol(''style'',''text'',''string'',num2str(eval(ns)),''position'',[sleng+180 ys+ksl*33 60 20]);end;'];
str1=[str1,printvalue];

%NPlot str
NPStr1=[' set(F2,''HandleVisibility'',''off'');figure(3);hold off; set(3,''Name'',''Mean centered ratio plot'');subplot(2,1,1);PlotMeanCenter=1;'];
NPStr1=[NPStr1,'mcgh_histfit(final_ratio1(IB)-m0-log2(ratio_calibration_value),30,m1-m0-log2(ratio_calibration_value),s1,p1,m0-m0-log2(ratio_calibration_value),s0,p0,m_1-m0-log2(ratio_calibration_value),s_1,p_1);'];
NPStr1=[NPStr1,'subplot(2,1,2);mcgh_plotClones(sorteddata,IA,IB,m0-m0-log2(ratio_calibration_value),s0,final_name1,final_ratio1-m0-log2(ratio_calibration_value),final_std1,sorteddata3,colname3);set(F2,''HandleVisibility'',''on'');'];

%ChrPlot str
ChrPStr1=[' set(F2,''HandleVisibility'',''off'');figure(4);hold off; set(4,''Name'',[''Chromosome '' num2str(ChrNo) '' plot'']);'];
ChrPStr1=[ChrPStr1,'mcgh_ChrPlot(sorteddata,IA,IB,m0-m0,s0,final_name1,final_ratio1-m0,final_std1,sorteddata3,colname3);'];
ChrPStr1=[ChrPStr1,'set(F2,''HandleVisibility'',''on'');'];


%for mmcgh export
str2=['figure(F1);hold off;set(F1,''Name'',''Raw ratio plot''); PlotMeanCenter=0; subplot(2,1,1);'];
str2=[str2,'mcgh_histfit(final_ratio1(IB),40,m1,s1,p1,m0,s0,p0,m_1,s_1,p_1);'];
str2=[str2,'subplot(2,1,2);mcgh_plotClones(sorteddata,IA,IB,m0,s0,final_name1,final_ratio1,final_std1,sorteddata3,colname3);'];
printvalue2=['figure(F2);for ksl=1:9;ns=char(nstring{ksl});ng(ksl)=uicontrol(''style'',''text'',''string'',num2str(eval(ns)),''position'',[sleng+180 ys+ksl*33 60 20]);end;'];
str2=[str2,printvalue2];
