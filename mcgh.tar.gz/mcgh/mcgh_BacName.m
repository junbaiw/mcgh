function f_name=mcgh_BacName(len,filtered_name1)
for i=1:len
    temp=strvcat(filtered_name1(i,:));
    idx=findstr('_',temp);
    if ~isempty(idx)
     f_name{i}=temp(1:idx(1)-1);
    else
     f_name{i}=temp;    
    end
end
