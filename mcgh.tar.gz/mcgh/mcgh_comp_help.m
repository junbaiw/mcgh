function [txtHndlList,HelpfigNumber]=mcgh_comp_help(titleStr,HelpfigNumber)
%%%%%%%%%%%%%%%%%%%
% HELPFN1 Utility function for displaying help text conveniently.
%       Modified by J.B.Wang, April. 2001
%       Modified by L. Kocbach, Nov. 1996
%       modified to work also on student edition, removed gco
%       Modification: removing the specific Expomap calls
%       Adding a string to change the title
%       titleStr,OnWhat,helpStr1,helpStr2,helpStr3
% Based on HELPFUN Utility function
%       Ned Gulley, 6-21-93
%       Copyright (c) 1984-94 by The MathWorks, Inc.
%
%Help file Based on Golden rule.
%

%titleStr='test';
%HelpfigNumber=3335;

OnWhat='M-CGH';
TextStrs=[	'Page 1'
     		'Page 2'
           'Page 3'
           'Page 4' ];
helpStr1= ...
   [
    '   The object of M-CGH is analyzing Microarray based CGH (compar-'
    'ative genomic hybridisation) experiments, where we first preproc-'
    'essing the raw Microarray expermental data and correcting various'
    'technical variations within each array. Then, based on the clean-'
    'ed data set, we applying more advanced mathematical methods to d-'
    'etect relative copy number changes between two genomes. Bellow is'
    'a breif introduction of the M-CGH toolbox. The raw experimental  '
    'data is obtained from QuantArray or GenPix. We load their export '
    'data as text (tab delimited) into M-CGH for further analysis.    '
    '                                                                 '
    'Features:                                                        '
    '   1. Pre-processing of raw microarray data i.e. simple global n-'
    '      ormalization, intensity dependent normalization and print  '
    '      position normalization.                                    '
    '   2. Computing the standard deviation of repeated spots.        '
    '   3. Plot the genome relative copy number changes against the g-'
    '      enome location with or without the error bar.              '
    '   4. The distributions of three classes of DNA copy numbers     '
    '      (gains, normal, losses) are estimated by maximum likelihood'
    '      method.                                                    '
    '   5. The estimation of the distributions of three classes of DNA'
    '      copy numbers can be manually adjusted by control sliders.  '
    '   6. The clone information will be shown in main window if use  '
    '      mouse click the data point in the plot.                    '
    '   7. More detailed clone information can be obtained from the   '
    '      Ensembl database by pressing Clone2Web button.             '
    '   8. The amplicon boundaries of CGH data can be computed by     '
    '      Fuzzy K-nearest neighbor method or wavelet approach.       '
    '   9. M-CGH did not require any other additional Matlab toolbox! '
    '                                                                 '
    'Author: J.B.Wang, Date: November, 2003.                          '];
helpStr2= ...
   [
    'This is a short description of how to use this toolbox:         '
    '                                                                '
    '   1. Check the export file of Quantarray or GenPix is in text ('
    '      tab delimited) format.                                    '
    '   2. Open matlab window and type command "mcgh" to launch      '
    '      the program.                                              '
    '   3. In "M-CGH" main window, load export file of Quantarray or '
    '      GenePix (i.e. demo_data/QuantArray_ExportMS8x3b.txt) and  '
    '      the pre-prepared clone location file (i.e. demo_data/Clone'
    '       _order_of_MS8x3b.txt).                                   '
    '   4. Select the input file format (QuantArray or GenePix),     '
    '      normalization method, compute amplicon boundarier or not, '
    '      and plot error bar or not etc,.                           '
    '   5. Click "Run program" button to run the program.            '
    '   6. For save the time of loading data, you can chose "Use last'
    '      loaded data" in the second round.                         '
    '   7. By using the control sliders, user can manually adjust the'
    '      centers of three DNA copy number changes.                 '  
    '   8. The clone information will be shown in the main window wh-'
    '      en user click the data point in the plot, more detailed   '
    '      information can be shown in the ENSEMBLE database when    '
    '      press "Clone2web" button.                                 '
    '   9. Click "Export data", the clone names, normalized ratios,  '
    '      and genome locations will be saved in a text file         '
    '      (.txtCloneRatio), where filtered spots are replaced by    '
    '      zero.                                                     '
    '   10. In "M-CGH" main window, press "EXIT" to exit the program.'];
helpStr3= ...
[    'Notes:                                                          '
     '                                                                '
     '  1. User can select "Use last loaded data" instead of "Load new'
     '     input data" when analyze the same data set in second time. '
     '  2. For the computation of amplicon boundaries, the average    '
     '     window size can be adjusted manually.                      '
     '  3. If clones are located at multiple chromosomes then each    '
     '     chromosome can be plotted on a separated figure (i.e. pop  '
     '     menu "Chr plot 1").                                        '
     '  4. In each plot, user can search for his interested clone by  '
     '     clicking the pop menu "M-CGH find Clone".                  '
     '  5. In M-CGH, all the plots can be saved as color image.       ' 
     '  6. M-CGH only works for QuantArray or GenePiX export file.    '
     '  7. At present, M-CGH only able to analyze single experiment.  '
     '  8. Sometimes, "M-CGH" main window maynot show the right clone ' 
     '     information when you click the data point in interactive   '
     '     plot, which are caused by the dense of data point within   '
     '     one plot. At such situation, you need zoom in the area of  '
     '     figure where you are interested in, by using MATLAB build  '
     '     in function "zoom in button". Then click your interested   '
     '     data point again and hope to get right clone information at'
     '     this time.                                                 '
     '  9. The clone location file can be updated/modified manually   '
     '     later but some important things you have to remember before'
     '     the changing.                                              '
     '  a) The order of "Chorsmor" should be arraned from 1 to 22 then'
     '     is x,y,OneQ, OncoQBAC and Extra.                           '
     '  b) if some Chorsmor is unavailable at current file then you   '
     '     only need type one row for each of them. For example,      '
     '     Chorsmor 2,3,4 are not available in current clone location '
     '     file then I put following lines instead (the first line is '
     '     the column names).                                         '
     '                                                                '
     '     BAC_PAC  Chorsmor position Order_Number Clone_order        '
     '     null     2        null     null         null               '
     '     null     3        null     null         null               '
     '     null     4        null     null         null               '
     '                                                                '
     '     You have to type the Chorsmor name in the clone location   '
     '     but the rest of information can use "null" instead.        '
 ];
helpStr4= ...
   ['Future development:                                             '
    '                                                                '      
    '   1. We are planing to extend current single CGH array analysis'
    '      to multiple array analysis.                               '
    '   2. M-CGH can be easily extended to analyze the export data of'
    '      other image analysis packages if their data format are    ' 
    '      available.                                                '];


numPages=4;
% If the Help Window has already been created, bring it to the front
newHelpWindowFlag=HelpfigNumber==1335;
figNumber=HelpfigNumber;
if newHelpWindowFlag,
    position=[50 30 520 440];
      %'NextPlot','new', ...
     % hidegui('on'); %%Added 12/11/01
    HelpfigNumber=figure( ...
        'Name',['MATLAB Info Window on ' OnWhat ], ...
        'NumberTitle','off', ...
        'Visible','off', ...
        'Position',position, ...
        'Colormap',[]); 
    figNumber=HelpfigNumber;
    %===================================
    % Set up the Help Window 
    top=0.95;
    left=0.05;
    right=0.75;
    bottom=0.05;
    labelHt=0.05;
    spacing=0.005;
    % First, the Text Window frame
    frmBorder=0.02;
    frmPos=[left-frmBorder bottom-frmBorder ...
        (right-left)+2*frmBorder (top-bottom)+2*frmBorder];
    uicontrol( ...
        'Style','frame', ...
        'Units','normalized', ...
        'Position',frmPos, ...
        'BackgroundColor',[0.5 0.5 0.5]);
    % Then the text label
     labelPos=[left top-labelHt (right-left) labelHt];
    ttlHndl=uicontrol( ...
        'Style','text', ...
        'Units','normalized', ...
        'Position',labelPos, ...
        'BackgroundColor',[0.5 0.5 0.5], ...
        'ForegroundColor',[1 1 1], ...
        'String',titleStr);
    % Then the editable text field (of which there are three)
    % Store the text field's handle two places: once in the figure
    % UserData and once in the button's UserData.
      for count=1:4,
        helpStr=eval(['helpStr',num2str(count)]);
        txtPos=[left bottom (right-left) top-bottom-labelHt-spacing];
        txtHndlList(count)=uicontrol( ...
            'Style','edit', ...
            'Units','normalized', ...
            'Max',20, ...
            'String',helpStr, ...
    	     'BackgroundColor',[1 1 1], ...
            'Visible','off', ...
            'Position',txtPos);
       end;
      set(txtHndlList(1),'Visible','on');

   %====================================
    % Information for all buttons
    labelColor=[0.8 0.8 0.8];
    top=0.95;
    bottom=0.05;   
    yInitPos=0.80;
    left=0.80;
    btnWid=0.15;  
    btnHt=0.10;
    % Spacing between the button and the next command's label
    spacing=0.05;
    % The CONSOLE frame
    frmBorder=0.02;
    yPos=bottom-frmBorder;
    frmPos=[left-frmBorder yPos btnWid+2*frmBorder 0.9+2*frmBorder];
    uicontrol( ...
        'Style','frame', ...
        'Units','normalized', ...
        'Position',frmPos, ...
        'BackgroundColor',[0.5 0.5 0.5]);
    %====================================
    % All required BUTTONS
    for count=1:4
        % The PAGE button
        labelStr=TextStrs(count,:);
        % The callback will turn off ALL text fields and then turn on
        % only the one referred to by the button.
        callbackStr= ...
           ['txtHndl=txtHndlList(' num2str(count) ');' ...
            'hndlList=get(gcf,''UserData'');' ...
            'set(hndlList(2:5),''Visible'',''off'');' ...
            'set(txtHndl,''Visible'',''on'');'];
        btnHndlList(count)=uicontrol( ...
            'Style','pushbutton', ...
            'Units','normalized', ...
            'Position',[left top-btnHt-(count-1)*(btnHt+spacing) btnWid btnHt],...
            'String',labelStr, ...
            'UserData',txtHndlList(count), ...
            'Visible','off', ...
            'Callback',callbackStr);
    end;
            
    %====================================
    % The CLOSE button
    callbackStr= ...
        'delete(gcf); HelpfigNumber=1335;';
    uicontrol( ...
        'Style','pushbutton', ...
        'Units','normalized', ...
        'Position',[left 0.05 btnWid 0.10], ...
        'String','Close', ...
        'Callback',callbackStr);
    
    hndlList=[ttlHndl txtHndlList btnHndlList];

    set(figNumber,'UserData',hndlList);
else
   figure(HelpfigNumber) ;
end;
% Now that we've determined the figure number, we can install the
% Desired strings.
hndlList=get(figNumber,'UserData');
ttlHndl=hndlList(1);
txtHndlList=hndlList(2:5);
btnHndlList=hndlList(6:9);
set(ttlHndl,'String',titleStr);
set(txtHndlList(2:4),'Visible','off');
set(txtHndlList(1),'Visible','on');
set(txtHndlList(1),'String',helpStr1,'HorizontalAlignment','left');
set(txtHndlList(2),'String',helpStr2,'HorizontalAlignment','left');
set(txtHndlList(3),'String',helpStr3,'HorizontalAlignment','left');
set(txtHndlList(4),'String',helpStr4,'HorizontalAlignment','left');

set(btnHndlList(1:numPages),'Visible','on');
set(HelpfigNumber,'Visible','on');
%%%%%    end   GUIhelp part
