function [rat_normed,int_normed]=mcgh_Snorm_type3(ch2_redsub,ch2_greensub,sumch2_redsub,...
    sumch2_greensub,ref1or2,figno,idxq_com,data)
global fileform
%Print position normalization of ratios 
%Input:
%ch2_redsub is channel 1 intensity after substracted background
%ch2_greensub is channel 2 intensity after substracted background
%sumch2_redsub is the sum of background substracted channel 1 intensity
%sumch2_greensub is the sum of background substracted channel 2 intensity
%ref1or2=1 compute ratio=ch2_greensub/ch2_redsub
%ref1or2=2 compute reatio=ch2_redsub/ch2_greensub
%figno is the figure number
%idxq_com is the ignore flag of input ch2_redsub and ch2_greensub
%Output:
%rat_normed is normalized ratio
%int_normed is normalized intensity
%The green line is the center of the data
%
%Notes:
%normalization type 1, assume both channel have
%equal intensity
if fileform==1
    print_position=[str2num(strvcat(data.Array_Row)),str2num(strvcat(data.Array_Column))];
    unique_print_position=unique(print_position,'rows'); 
    numof_arrayBlock=length(unique_print_position);
    spt=strvcat(num2str(print_position)); %string of all print position
    
elseif fileform==2
    print_position=str2num(strvcat(data.Block));
    unique_print_position=unique(print_position);
    numof_arrayBlock=length(unique_print_position);
    spt=strvcat(num2str(print_position)); %string of all print position
end

warning off;
%compute each block's normalization factor
for arrayI=1:numof_arrayBlock
    upt=[];
    idx_spt=[];
    
    if fileform==1
        upt=strvcat(num2str(unique_print_position(arrayI,:))); %string of block i's print position
        idx_spt=strmatch(deblank(upt),deblank(spt),'rows') ;%find index of upt in spt
    elseif fileform==2
        upt=unique_print_position(arrayI,:); %string of block i's print position
        idx_spt=find(str2num(spt)==upt) ;%find index of upt in spt
    end
    
    
    sumch2_redsub=sum(sum(ch2_redsub(idx_spt))); % not include bad spots and flaged spots in Normalizations
    sumch2_greensub=sum(sum(ch2_greensub(idx_spt)));
    
    %start normaliz in each block  
    
    if ref1or2==1
	    red_norm=sumch2_redsub./sumch2_redsub;
	    green_norm=sumch2_greensub./sumch2_redsub; %Ch2/ch1 normalization factor=Green/red, ch1 as reference channel
            normalized_factor(arrayI)=green_norm;
        
	    ch2_redInt_normed(idx_spt)=ch2_redsub(idx_spt)./red_norm;
	    ch2_greenInt_normed(idx_spt)=ch2_greensub(idx_spt)./green_norm;
   
            red_ratio_normed(idx_spt)=ch2_redInt_normed(idx_spt)./ch2_redInt_normed(idx_spt);
	    green_ratio_normed(idx_spt)=ch2_greenInt_normed(idx_spt)./ch2_redInt_normed(idx_spt);
           %  marray_debuge('ratio=532/635');	
    elseif ref1or2==2
        red_norm=sumch2_redsub./sumch2_greensub;
        green_norm=sumch2_greensub./sumch2_greensub; %Ch1/ch2 normalization factor=Red/Green, ch2 as reference channel
   
        normalized_factor(arrayI)=red_norm;
          
        ch2_redInt_normed(idx_spt)=ch2_redsub(idx_spt)./red_norm;
        ch2_greenInt_normed(idx_spt)=ch2_greensub(idx_spt)./green_norm;
        red_ratio_normed(idx_spt)=ch2_redInt_normed(idx_spt)./ch2_greenInt_normed(idx_spt);
        green_ratio_normed(idx_spt)=ch2_greenInt_normed(idx_spt)./ch2_greenInt_normed(idx_spt);
        % marray_debuge('ratio=635/532');
    else
        disp('Please choose right channel to normalize');
        stop ;   
    end
    %red_norm
    %green_norm
end %end for

%replace inf, nan to zero
infidx=find(isinf(red_ratio_normed)==1); red_ratio_normed(infidx)=0;
nanidx=find(isnan(red_ratio_normed)==1); red_ratio_normed(nanidx)=0;
infidx=find(isinf(green_ratio_normed)==1); green_ratio_normed(infidx)=0;
nanidx=find(isnan(green_ratio_normed)==1); green_ratio_normed(nanidx)=0;

infidx=find(isinf(ch2_redInt_normed)==1); ch2_redInt_normed(infidx)=0;
nanidx=find(isnan(ch2_redInt_normed)==1); ch2_redInt_normed(nanidx)=0;
infidx=find(isinf(ch2_greenInt_normed)==1); ch2_greenInt_normed(infidx)=0;
nanidx=find(isnan(ch2_greenInt_normed)==1); ch2_greenInt_normed(nanidx)=0;

rat_normed=[red_ratio_normed', green_ratio_normed'];
int_normed=[ch2_redInt_normed', ch2_greenInt_normed'];  

idxgood=find(idxq_com==1);
marray_SbefVaftnormPlot3(ch2_redsub(idxgood),ch2_greensub(idxgood),ch2_redInt_normed(idxgood),...
    ch2_greenInt_normed(idxgood),ref1or2,figno,arrayI,normalized_factor);

%plot block norm factor
%figure(22)
%p1=plot(1:arrayI,normalized_factor,'.');
%grid on;
%set(p1,'MarkerSize',10);
%xlabel('Blcok','FontSize',13);
%ylabel('Normalization factor','FontSize',13);
%axis([0 30 0 2]);
%title('Print position normalization','FontSize',13);
